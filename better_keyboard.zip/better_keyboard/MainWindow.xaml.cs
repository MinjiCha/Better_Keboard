﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace better_keyboard
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        private Boolean QWERTYFirst = true;
        private Boolean IsOPTIGo;

        DispatcherTimer dt = new DispatcherTimer();
        Stopwatch sw = new Stopwatch();
        string currentTime = string.Empty;

        private TimeSpan currFallBackTime;

        private MediaPlayer mediaPlayer_tick = new MediaPlayer();
        private MediaPlayer mediaPlayer_beep = new MediaPlayer();

        int QWERTY = 0;
        int SKY = 0;

        int shift = 0;
        int sky = 0;
        int[] press = new int[7] { 0,0,0,0,0,0,0 };

        int stage = 0;
        String currPhrase;
        int currInputIndex = 0;

        public MainWindow()
        {
            InitializeComponent();

            MainController.Instance._MainWindow = this;
            MainController.Instance._Qwerty = QWERTY_Key;
            MainController.Instance._Sky = Sky_Key;
            
            mediaPlayer_tick.Open(new Uri("./tick.mp3", UriKind.Relative));
            mediaPlayer_beep.Open(new Uri("./beep.mp3", UriKind.Relative));

            dt.Tick += new EventHandler(dt_Tick);
            dt.Interval = new TimeSpan(0, 0, 0, 0, 1);
        }

        public void ApplyInput(String input)
        {
            mediaPlayer_tick.Stop();
            mediaPlayer_beep.Stop();
            mediaPlayer_tick.Position = TimeSpan.Zero;
            mediaPlayer_beep.Position = TimeSpan.Zero;

            if (shift == 1)
            {
                shift = 0;
                if (input == "ㅐ(ㅒ)") input = "ㅒ";
                else if (input == "ㅔ(ㅖ)") input = "ㅖ";
                else if (input == "ㅂ") input = "ㅃ";
                else if (input == "ㅈ") input = "ㅉ";
                else if (input == "ㄷ") input = "ㄸ";
                else if (input == "ㄱ") input = "ㄲ";
                else if (input == "ㅅ") input = "ㅆ";
                else if (input == "SPACE") input = " ";
                else if (input == "Shift")
                {
                    input = null;
                    currInputIndex--;
                    shift = 1;
                }
            }
            else
            {
                if (input == "SPACE") input = " ";
                if (input == "ㅐ(ㅒ)") input = "ㅐ";
                else if (input == "ㅔ(ㅖ)") input = "ㅔ";
                else if (input == "Shift")
                {
                    input = null;
                    currInputIndex--;
                    shift = 1;
                }

                if (sky == 2)
                {
                    if ((input == "ㄱㅋ") && press[0] == 2)
                    {
                        input = "ㄲ";
                    }
                    else if ((input == "ㄷㅌ") && press[2] == 2)
                    {
                        input = "ㄸ";
                    }
                    else if ((input == "ㅂㅍ") && press[3] == 2)
                    {
                        input = "ㅃ";
                    }
                    else if ((input == "ㅅㅎ") && press[4] == 2)
                    {
                        input = "ㅆ";
                    }
                    else if ((input == "ㅈㅊ") && press[5] == 2)
                    {
                        input = "ㅉ";
                    }
                    else if ((input == "ㅇㅁ") && press[6] == 2)
                    {
                        input = "ㅁ";
                    }
                    for (int i = 0; i < 7; i++)
                    {
                        press[i] = 0;
                    }
                    sky = 0;
                }
                if (sky == 1)
                {
                    if ((input == "ㄱㅋ") && (press[0] == 1))
                    {
                        input = "ㅋ";
                        press[0]++;
                        sky++;
                    }
                    else if ((input == "ㄴㄹ") && (press[1] == 1))
                    {
                        input = "ㄹ";
                        press[1] = 0;
                    }
                    else if ((input == "ㄷㅌ") && (press[2] == 1))
                    {
                        input = "ㅌ";
                        press[2]++;
                        sky++;
                    }
                    else if ((input == "ㅂㅍ") && (press[3] == 1))
                    {
                        input = "ㅍ";
                        press[3]++;
                        sky++;
                    }
                    else if ((input == "ㅅㅎ") && (press[4] == 1))
                    {
                        input = "ㅎ";
                        press[4]++;
                        sky++;
                    }
                    else if ((input == "ㅈㅊ") && (press[5] == 1))
                    {
                        input = "ㅊ";
                        press[5]++;
                        sky++;
                    }
                    else if ((input == "ㅇㅁ") && (press[6] == 1))
                    {
                        input = "ㅁ";
                        press[6] = 0;
                    }
                    else
                    {
                        for (int i = 0; i< 7; i++)
                        {
                            press[i] = 0;
                        }
                        sky = 0;
                    }
                }
                if (sky == 0)
                {
                    if (input == "ㄱㅋ")
                    {
                        input = "ㄱ";
                        press[0]++;
                        sky++;
                    }
                    else if (input == "ㄴㄹ")
                    {
                        input = "ㄴ";
                        press[1]++;
                        sky++;
                    }
                    else if (input == "ㄷㅌ")
                    {
                        input = "ㄷ";
                        press[2]++;
                        sky++;
                    }
                    else if (input == "ㅂㅍ")
                    {
                        input = "ㅂ";
                        press[3]++;
                        sky++;
                    }
                    else if (input == "ㅅㅎ")
                    {
                        input = "ㅅ";
                        press[4]++;
                        sky++;
                    }
                    else if (input == "ㅈㅊ")
                    {
                        input = "ㅈ";
                        press[5]++;
                        sky++;
                    }
                    else if (input == "ㅇㅁ")
                    {
                        input = "ㅇ";
                        press[6]++;
                        sky++;
                    }
                    else sky = 0;
                }
            }
            Input.Text += input;

            String answer=null;

            if (currInputIndex != -1)
            {
                answer = currPhrase.Substring(currInputIndex, 1);
            }

            if ((input != answer)&&(input!=null))
            {
                Time.Instance.ErrorWordNums++;
                Console.WriteLine(Time.Instance.ErrorWordNums);
                mediaPlayer_beep.Play();
            }
            else
            {
                mediaPlayer_tick.Play();
            }

            Time.Instance.WordNums++;
            currInputIndex++;

            if(Input.Text.Length == Parse.Text.Length)
            {
                currPhrase = Time.Instance.GetSample();
                Input.Text = "";
                currInputIndex = 0;
            }

            Refresh();
        }

        public void Refresh() // 뭐가 문제지
        {
            String first = currPhrase.Substring(0, currInputIndex);
            String highlight = currPhrase.Substring(currInputIndex, 1);
            if (highlight == " ") highlight = "_";
            String last = currPhrase.Substring(currInputIndex + 1, currPhrase.Length - currInputIndex - 1);
            Parse.Inlines.Clear();
            Parse.Inlines.Add(new Run(first));
            Run highlightRun = new Run();
            highlightRun.Foreground = Brushes.Red;
            highlightRun.Text = highlight;
            Parse.Inlines.Add(highlightRun);
            Parse.Inlines.Add(new Run(last));
        }

        public void MainStage()
        {
            if (QWERTY == 1) Time.Instance.ReadSamples();
            else if (SKY == 1) Time.Instance.ReadSkySamples();

            if (stage == 0) //READY
            {
                QWERTY_Speed.Text = "speed ( wpm ) :";
                SKY_Speed.Text = "speed ( wpm ) :";
                QWERTY_Error.Text = "error rate :";
                SKY_Error.Text = "error rate :";

                Ready.Visibility = Visibility.Visible;
                currFallBackTime = Time.Instance.ReadyTime; //레디 10초
            }
            else if (stage == 1) //세션-1
            {
                Ready.Visibility = Visibility.Collapsed;
                InitializeKeyBoardLayout(true);
                Time.Instance.InitializeSession();
                currInputIndex = 0;

                currPhrase = Time.Instance.GetSample();
                Refresh();
                currFallBackTime = Time.Instance.SessionTime; // 세션 3분
                sw.Restart();
            }
            else if (stage == 2) // 휴식
            {
                Double record = Time.Instance.GetWordPerMinute();
                Double record2 = Time.Instance.GetErrorRate();
                MessageBox.Show("Result : \nWPM: " + record + " / Error Rate : " + record2, "QWERTY vs Sky");
                if (IsOPTIGo == true)
                {
                    SKY_Speed.Text = "speed(wpm) : " + record.ToString();
                    SKY_Error.Text = "error rate: " + record2.ToString();
                }
                else
                {
                    QWERTY_Speed.Text = "speed(wpm) : " + record.ToString();
                    QWERTY_Error.Text = "error rate: " + record2.ToString();

                }

                Ready.Visibility = Visibility.Visible;
                ClearKeyBoardLayout();
                Sample.Text = "";
                Parse.Text = "";
                Input.Text = "";

                currFallBackTime = Time.Instance.restFallBackTime; // 휴식 1분
                sw.Restart();
            }
            else if (stage == 3) // 세션-2
            {
                if (QWERTY == 1) Time.Instance.ReadSkySamples();
                else if (SKY == 1) Time.Instance.ReadSamples();

                Ready.Visibility = Visibility.Collapsed;
                InitializeKeyBoardLayout(false);
                Time.Instance.InitializeSession();
                currInputIndex = 0;

                currPhrase = Time.Instance.GetSample();
                Refresh();
                currFallBackTime = Time.Instance.SessionTime; // 세션 3분
                sw.Restart();
            }
            else
            {
                Double record = Time.Instance.GetWordPerMinute();
                Double record2 = Time.Instance.GetErrorRate();
                MessageBox.Show("REsult :\nWPM " + record + " / Error Rate : " + record2, "QWERTY VS SKY");
                if (IsOPTIGo == true)
                {
                    SKY_Speed.Text = "speed(wpm) : " + record.ToString();
                    SKY_Error.Text = "error rate: " + record2.ToString();
                }
                else
                {
                    QWERTY_Speed.Text = "speed(wpm) : " + record.ToString();
                    QWERTY_Error.Text = "error rate: " + record2.ToString();

                }

                ClearKeyBoardLayout();
                Sample.Text = "";
                Parse.Text = "";
                Input.Text = "";
                sw.Stop();
            }
        }

        void dt_Tick(object sender, EventArgs e)
        {
            if (sw.IsRunning)
            {
                TimeSpan ts = currFallBackTime - sw.Elapsed;

                currentTime = String.Format("{0:00}:{1:00}", ts.Minutes, ts.Seconds);
                time.Text = currentTime;

                if (currentTime == "00:00") Ready.Text = "START!";
                else Ready.Text = "Ready (" + currentTime + ")";
                if (ts.Ticks < 0)
                {
                    stage++;
                    MainStage();
                }
            }
        }

        private void InitializeKeyBoardLayout(Boolean isFirst)
        {
            IsOPTIGo = QWERTYFirst ^ isFirst;
            if(IsOPTIGo == true)
            {
                QWERTY_Key.Visibility = Visibility.Collapsed;
                Sky_Key.Visibility = Visibility.Visible;
            }
            else
            {
                QWERTY_Key.Visibility = Visibility.Visible;
                Sky_Key.Visibility = Visibility.Collapsed;
            }
        }

        private void ClearKeyBoardLayout()
        {
            QWERTY_Key.Visibility = Visibility.Collapsed;
            Sky_Key.Visibility = Visibility.Collapsed;
        }

        private void Start_Click(object sender, RoutedEventArgs e)
        {
            sw.Start();
            stage = 0;
            MainStage();
            dt.Start();
        }

        private void Stop_Click(object sender, RoutedEventArgs e)
        {
            if (sw.IsRunning)
            {
                sw.Stop();
                sw.Reset();

                Ready.Visibility = Visibility.Collapsed;
                ClearKeyBoardLayout();
                Sample.Text = "";
                Parse.Text = "";
                Input.Text = "";
            }
            /*stage = 0;
            sw.Reset();
            MainStage();
            time.Text = "00:00";*/
        }

        private void First_Checked(object sender, RoutedEventArgs e)
        {
            QWERTY = 1;
            SKY = 0;
            RadioButton rb = (RadioButton)sender;
            String id = (String)rb.Tag;
            QWERTYFirst = true;
        }

        private void Second_Checked(object sender, RoutedEventArgs e)
        {
            SKY = 1;
            QWERTY = 0;
            RadioButton rb = (RadioButton)sender;
            String id = (String)rb.Tag;
            QWERTYFirst = false;
        }
    }
}
