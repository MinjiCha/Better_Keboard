﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace better_keyboard
{
    public class Time
    {
        public static Time Instance { get; private set; }

        public List<String> Samples = new List<String>();
        public List<int> UsedIndices;
        
        public readonly TimeSpan ReadyTime = new TimeSpan(0, 0, 0, 6,0); // 처음 준비 시간
        public readonly TimeSpan SessionTime = new TimeSpan(0, 0, 5, 1,0); // task 수행 시간
        public readonly TimeSpan restFallBackTime = new TimeSpan(0, 0, 0, 31, 0); // 중간 휴식 시간

        public int WordNums;
        public int ErrorWordNums;
        public double WordPerMinute;

        public List<Int32> Used;

        static Time()
        {
            Instance = new Time();
        }

        public void ReadSamples() {
        
            String line;

            Encoding encode = System.Text.Encoding.GetEncoding("ks_c_5601-1987");

            StreamReader file = new StreamReader("ParseSample.txt");
            while ((line = file.ReadLine()) != null)
            {
                Console.WriteLine(line);
                Samples.Add(line);
            }
            file.Close();
        }

        public void ReadSkySamples()
        {
            String line;
            Encoding encode = System.Text.Encoding.GetEncoding("ks_c_5601-1987");

            StreamReader file = new StreamReader("SkyParseSample.txt");
            while ((line = file.ReadLine()) != null){
                Console.WriteLine(line);
                Samples.Add(line);
            }
            file.Close();
        }

        public void ReadRealSamples()
        {
            String line;
            Encoding encode = System.Text.Encoding.GetEncoding("ks_c_5601-1987");

            StreamReader file = new StreamReader("Sample.txt");
            while ((line = file.ReadLine()) != null)
            {
                Console.WriteLine(line);
                Samples.Add(line);
            }
            file.Close();
        }

        public void InitializeSession()
        {
            WordNums = 0;
            ErrorWordNums = 0;
            Used = new List<Int32>();
        }

        public String GetSample()
        {
            int min = 0;
            int max = Samples.Count - 1;
            Random rand = new Random();

            int pick;
            do
            {
                pick = rand.Next(min, max);
            } while (Used.Contains(pick) == true);

            Used.Add(pick);
            return Samples[pick];
        }

        public Double GetWordPerMinute()
        {
            Double res = WordNums / (Double)SessionTime.Minutes;
            return Math.Round(res, 2);
        }

        public Double GetErrorRate()
        {
            Double res = ErrorWordNums / (Double)WordNums;
            return Math.Round(res, 2);
        }
    }
}
