﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace better_keyboard
{
    public class MainController
    {
        public MainWindow _MainWindow;
        public Sky _Sky;
        public Qwerty _Qwerty;

        public static MainController Instance { get; private set; }

        static MainController()
        {
            Instance = new MainController();
        }
        private MainController() { }
        public void SendingInput(String input)
        {
            _MainWindow.ApplyInput(input);
        }
    }
}
